import asyncio
import os
import tempfile

import discord


async def speak(voice_client, text):
    try:
        import edge_tts
    except ImportError:
        raise RuntimeError(
            "edge-tts is not installed. Add edge-tts to requirements.txt."
        )

    if not voice_client or not voice_client.is_connected():
        raise RuntimeError("Discord voice connection is not active.")

    fd, filename = tempfile.mkstemp(suffix=".mp3")
    os.close(fd)

    try:
        communicate = edge_tts.Communicate(
            text,
            "en-US-AriaNeural"
        )
        await communicate.save(filename)

        if voice_client.is_playing():
            voice_client.stop()

        finished = asyncio.Event()

        def after_play(error):
            if error:
                print("❌ Voice playback error:", repr(error))
            try:
                loop = asyncio.get_running_loop()
                loop.call_soon_threadsafe(finished.set)
            except RuntimeError:
                pass

        source = discord.FFmpegOpusAudio(filename)
        voice_client.play(source, after=after_play)

        await finished.wait()

    finally:
        try:
            os.remove(filename)
        except OSError:
            pass
