import sqlite3
import threading
from pathlib import Path


class Memory:
    def __init__(self, database_path="king_zarry_memory.db"):
        self.database_path = str(database_path or "king_zarry_memory.db")
        Path(self.database_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self):
        return sqlite3.connect(self.database_path)

    def _init_db(self):
        with self._lock, self._connect() as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            db.commit()

    def add(self, user_id, role, content):
        if not content:
            return
        with self._lock, self._connect() as db:
            db.execute(
                "INSERT INTO messages (user_id, role, content) VALUES (?, ?, ?)",
                (str(user_id), role, str(content))
            )
            db.commit()

    def get(self, user_id, limit=12):
        with self._lock, self._connect() as db:
            rows = db.execute("""
                SELECT role, content
                FROM messages
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT ?
            """, (str(user_id), int(limit))).fetchall()
        rows.reverse()
        return [{"role": role, "content": content} for role, content in rows]

    def clear(self, user_id):
        with self._lock, self._connect() as db:
            db.execute(
                "DELETE FROM messages WHERE user_id = ?",
                (str(user_id),)
            )
            db.commit()
