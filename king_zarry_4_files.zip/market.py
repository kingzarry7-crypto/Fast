import requests

from config import TWELVE_DATA_API_KEY, TWELVE_DATA_URL


TIMEFRAME_MAP = {
    "1m": "1min",
    "5m": "5min",
    "15m": "15min",
    "30m": "30min",
    "1h": "1h",
    "2h": "2h",
    "4h": "4h",
    "1d": "1day",
}


def normalize_timeframe(timeframe):
    timeframe = str(timeframe).lower().strip()
    return TIMEFRAME_MAP.get(timeframe, timeframe)


def _request(endpoint, params):
    if not TWELVE_DATA_API_KEY:
        raise RuntimeError("TWELVE_DATA_API_KEY is missing.")

    response = requests.get(
        f"{TWELVE_DATA_URL}/{endpoint}",
        params={**params, "apikey": TWELVE_DATA_API_KEY},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()

    if data.get("status") == "error":
        raise RuntimeError(data.get("message", "Twelve Data error."))

    return data


def get_price(symbol):
    data = _request("price", {"symbol": symbol})
    if "price" not in data:
        raise RuntimeError(f"Unexpected price response: {data}")
    return float(data["price"])


def get_candles(symbol, timeframe="15m", outputsize=100):
    interval = normalize_timeframe(timeframe)
    data = _request(
        "time_series",
        {
            "symbol": symbol,
            "interval": interval,
            "outputsize": outputsize
        }
    )

    values = data.get("values")
    if not values or len(values) < 50:
        raise RuntimeError("Not enough market data.")

    return list(reversed(values))


def ema(values, period):
    if len(values) < period:
        return None

    multiplier = 2 / (period + 1)
    result = sum(values[:period]) / period

    for price in values[period:]:
        result = ((price - result) * multiplier) + result

    return result


def rsi(values, period=14):
    if len(values) < period + 1:
        return None

    gains = []
    losses = []

    for i in range(1, len(values)):
        change = values[i] - values[i - 1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    for i in range(period, len(gains)):
        avg_gain = ((avg_gain * (period - 1)) + gains[i]) / period
        avg_loss = ((avg_loss * (period - 1)) + losses[i]) / period

    if avg_loss == 0:
        return 100.0

    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def analyze_market(symbol, timeframe="15m"):
    interval = normalize_timeframe(timeframe)
    candles = get_candles(symbol, interval, 100)

    closes = [float(c["close"]) for c in candles]
    highs = [float(c["high"]) for c in candles]
    lows = [float(c["low"]) for c in candles]

    price = closes[-1]
    ema9 = ema(closes, 9)
    ema21 = ema(closes, 21)
    ema50 = ema(closes, 50)
    current_rsi = rsi(closes, 14)

    if None in (ema9, ema21, ema50, current_rsi):
        raise RuntimeError("Indicators could not be calculated.")

    support = min(lows[-20:])
    resistance = max(highs[-20:])

    score = 0

    if ema9 > ema21:
        score += 1
    else:
        score -= 1

    if ema21 > ema50:
        score += 1
    else:
        score -= 1

    if price > ema21:
        score += 1
    else:
        score -= 1

    if current_rsi > 50:
        score += 1
    elif current_rsi < 50:
        score -= 1

    if score >= 3:
        signal = "BUY"
        trend = "BULLISH"
    elif score <= -3:
        signal = "SELL"
        trend = "BEARISH"
    else:
        signal = "WAIT"
        trend = "NEUTRAL"

    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "price": price,
        "signal": signal,
        "trend": trend,
        "support": support,
        "resistance": resistance,
        "ema9": ema9,
        "ema21": ema21,
        "ema50": ema50,
        "rsi": current_rsi,
    }
