import base64
import requests

from config import (
    AI_PROVIDER,
    GEMINI_API_KEY,
    GEMINI_MODEL,
    GEMINI_URL,
    OPENAI_API_KEY,
    OPENAI_MODEL,
    OPENAI_URL,
)


SYSTEM_PROMPT = """
You are King Zarry AI 👑, the official AI assistant for the King Zarry community.

You help with:
• Cryptocurrency and Bitcoin
• Forex and Gold / XAUUSD
• Technical analysis and market structure
• Risk management
• Programming, AI and technology
• Business and general questions
• Casual conversation

TRADING RULES:
Never guarantee profit or claim certainty about future market movement.
Clearly distinguish confirmed information, probable scenarios, and uncertainty.
Never invent live prices. Only use live data when it is actually supplied.
For trading setups, explain direction, entry area, invalidation/stop, targets,
risk/reward and reasoning. If the data is insufficient, say WAIT.

Be practical, clear and concise. Use emojis naturally.
You are King Zarry AI 👑.
"""


class AIEngine:
    def __init__(self, memory):
        self.memory = memory

    def ask(self, user_id, prompt, image=None):
        history = self.memory.get(user_id, 12)

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ]
        messages.extend(history)
        messages.append({"role": "user", "content": prompt})

        errors = []

        if AI_PROVIDER == "GEMINI":
            answer = self._gemini(messages, image)
        elif AI_PROVIDER == "OPENAI":
            answer = self._openai(messages, image)
        else:
            if GEMINI_API_KEY:
                try:
                    answer = self._gemini(messages, image)
                except Exception as e:
                    errors.append(f"Gemini: {e}")
                    answer = None
            else:
                answer = None

            if not answer and OPENAI_API_KEY:
                try:
                    answer = self._openai(messages, image)
                except Exception as e:
                    errors.append(f"OpenAI: {e}")
                    answer = None

            if not answer:
                raise RuntimeError(
                    "No AI provider was able to respond.\n" +
                    "\n".join(errors)
                )

        self.memory.add(user_id, "user", prompt)
        self.memory.add(user_id, "assistant", answer)
        return answer

    def _gemini(self, messages, image=None):
        if not GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is not configured.")

        parts = []
        for message in messages:
            if message["role"] == "system":
                continue
            content = message["content"]
            if isinstance(content, str):
                parts.append({"text": content})

        if image:
            mime_type, image_bytes = image
            parts.append({
                "inline_data": {
                    "mime_type": mime_type,
                    "data": base64.b64encode(image_bytes).decode("utf-8")
                }
            })

        payload = {
            "systemInstruction": {
                "parts": [{"text": SYSTEM_PROMPT}]
            },
            "contents": [{
                "role": "user",
                "parts": parts
            }],
            "generationConfig": {
                "temperature": 0.3,
                "maxOutputTokens": 1800
            }
        }

        url = f"{GEMINI_URL}/{GEMINI_MODEL}:generateContent"
        response = requests.post(
            url,
            headers={
                "x-goog-api-key": GEMINI_API_KEY,
                "Content-Type": "application/json"
            },
            json=payload,
            timeout=120
        )

        if response.status_code != 200:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(f"Gemini API error: {detail}")

        data = response.json()
        text_parts = []

        for candidate in data.get("candidates", []):
            for part in candidate.get("content", {}).get("parts", []):
                if "text" in part:
                    text_parts.append(part["text"])

        answer = "\n".join(text_parts).strip()
        if not answer:
            raise RuntimeError(f"Gemini returned no text: {data}")

        return answer

    def _openai(self, messages, image=None):
        if not OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY is not configured.")

        prepared = []

        for message in messages:
            prepared.append({
                "role": message["role"],
                "content": message["content"]
            })

        if image:
            mime_type, image_bytes = image
            data_url = (
                f"data:{mime_type};base64,"
                f"{base64.b64encode(image_bytes).decode('utf-8')}"
            )
            prepared.append({
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Analyze the attached image carefully."
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": data_url,
                            "detail": "high"
                        }
                    }
                ]
            })

        response = requests.post(
            OPENAI_URL,
            headers={
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": OPENAI_MODEL,
                "messages": prepared,
                "temperature": 0.3,
                "max_tokens": 1800
            },
            timeout=120
        )

        if response.status_code != 200:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise RuntimeError(f"OpenAI API error: {detail}")

        data = response.json()
        try:
            answer = data["choices"][0]["message"]["content"]
        except Exception:
            raise RuntimeError(f"Unexpected OpenAI response: {data}")

        if not answer:
            raise RuntimeError("OpenAI returned no text.")

        return answer.strip()
